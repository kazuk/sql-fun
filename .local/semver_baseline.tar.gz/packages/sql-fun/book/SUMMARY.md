# `sql-fun` User manual

- [Introduction](./introduction.md)
- [Installation](./installation.md)
- [SQLite project bootstrap](./sqlite-bootstrap.md)
- [SQL Functions](./sql_functions.md)
- [Collecting ordered rows](./sql_fun_collector.md)
- [Reusable CTE](./reusable_cte.md)
- [Database Performance Management](./database-performance-management.md)
- [Design philosophies](./design-philosophies.md)

## SQL re-write features

- [Batch query support](./sql-rewrite/batching.md)

## `sql-fun` command line reference

### Subcommands

- [init](./cli/init.md) sub command
- [Extract PostgreSQL metadata](cli/extract.md)
- [check](./cli/check.md) sub command
<!-- Empty links mark draft chapters in mdBook. -->
<!-- rumdl-disable MD042 -->
- [api]()
- [api-help]()
<!-- rumdl-enable MD042 -->

## `sql-fun` server api reference

### methods

- [initialize method](./api/initialize.md)
- [initialized notification](./api/initialized.md)
- [list-tables method](./api/list-tables.md)
<!-- Empty links mark draft chapters in mdBook. -->
<!-- rumdl-disable MD042 -->
- [describe-table method]()
- [validate-sql method]()
<!-- rumdl-enable MD042 -->
