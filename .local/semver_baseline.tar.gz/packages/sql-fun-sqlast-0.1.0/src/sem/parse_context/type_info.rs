use crate::sem::{
    CreateCompositType, CreateDomain, CreateEnum, FullName, TableName, TypeDefinition,
    TypeReference,
};

/// get type definition
pub trait TypeInfoRead {
    /// get type by name
    fn get_type_impl(&self, key: &FullName) -> Option<&TypeDefinition>;

    /// get item type for array type
    fn get_array_item_type(&self, type_name: &TypeReference) -> Option<TypeReference>;
}

/// store and update type info
pub trait TypeInfoWrite
where
    Self: Sized,
{
    /// insert table reference composite type
    fn insert_table_ref_type(&mut self, name: &TableName);

    /// register enum type
    fn insert_create_composite_type(
        &mut self,
        name: &FullName,
        create_comp_type: &CreateCompositType,
    );

    /// insert create domain statement
    fn insert_create_domain(&mut self, name: &FullName, create_domain: &CreateDomain);

    /// register enum type
    fn insert_create_enum(&mut self, name: &FullName, create_enum_type: &CreateEnum);
}
