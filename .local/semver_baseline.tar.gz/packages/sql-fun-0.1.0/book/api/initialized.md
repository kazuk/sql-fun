# initialized notification
